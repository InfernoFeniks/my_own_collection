# Ansible Collection - infernofeniks.yandex_cloud_elk

Easy creation of a file with content
